#define SIZE_X 256
#define SIZE_Y 256
#define PIXEL_WIDTH 2
#define SQUARE_WIDTH 16
#define SQUARE_COUNT 4
